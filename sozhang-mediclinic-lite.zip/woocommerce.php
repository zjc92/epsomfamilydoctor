<?php get_header(); ?>
<div class="container">
<div id="tabnavigator">
     <div class="template_contentbx fullwidth">  
			<?php woocommerce_content(); ?>
    </div><!-- template_contentbx-->   
</div><!-- #tabnavigator --> 
</div><!-- .container -->     
<?php get_footer(); ?>